/* ==================
 脚本类型: NPC	    
 脚本版权：游戏盒团队
 联系扣扣：297870163    609654666
 =====================
 */
function start() {
    cm.sendOk("你好。我科迪。很高兴认识你! =)");
}

function action(mode, type, selection) {
    cm.dispose();
}	