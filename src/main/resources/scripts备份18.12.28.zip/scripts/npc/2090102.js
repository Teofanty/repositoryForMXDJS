/* Romi
	Orbis Skin Change.
*/
var status = -1;
var skin = [0, 1, 2, 3, 4];

function start() {
    action(1, 0, 0);
}

function action(mode, type, selection) {
    if (mode == 0) {
	cm.dispose();
	return;
    } else {
	status++;
    }

    if (status == 0) {
	cm.sendNext("你好！ 欢迎来到沐隆护肤品！ 你想拥有像我一样坚固，紧致，健康的肌肤吗？同 #b#t5153006##k,你可以让我们照顾好休息，拥有你一直想要的那种皮肤~!");
    } else if (status == 1) {
	cm.askAvatar("使用我们的专用机器，您可以在手术前看到治疗方式。 你在寻找什么样的外观？ 来吧，选择你喜欢的风格〜!", skin);
    } else if (status == 2){
	if (cm.setAvatar(5153006, skin[selection]) == 1) {
	    cm.sendOk("享受新的和改善的皮肤!");
		cm.dispose();
	} else {
	    cm.sendOk("嗯......你没有接受治疗所需的护肤券。 对不起，但我担心我们不能帮你...");
		cm.dispose();
	}
	cm.dispose();
    }
}