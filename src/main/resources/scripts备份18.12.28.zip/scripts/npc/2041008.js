/*
	Seppy - Ludibrium : Ludibrium (220000000)
*/

function start() {
    cm.sendStorage();
    cm.dispose();
}