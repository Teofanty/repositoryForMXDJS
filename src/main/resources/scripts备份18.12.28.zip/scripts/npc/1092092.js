/* ==================
 脚本类型: NPC	    
 脚本版权：游戏盒团队
 联系扣扣：297870163    609654666
 =====================
 */
function start() {
    cm.removeAll(4031847);
    cm.removeAll(4031848);
    cm.removeAll(4031849);
    cm.gainItem(4031850, 1);
    cm.warp(120000100, 0);
    cm.dispose();
}