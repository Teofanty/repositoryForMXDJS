/* ==================
 脚本类型: NPC	    
 脚本作者：维多   
 联系方式：297870163
 =====================
 */

var status;
var fbmc = "水下世界-(骑宠任务)";//副本名称
var minLevel = 70;//最低等级
var maxLevel = 200;//最高等级
var minPartySize = 1;//最低人数
var maxPartySize = 6;//最高人数
var cishuxianzhi = 3;//限制次数
var eventname = "Qichong";//副本配置文件

function start() {
    status = -1;
    action(1, 0, 0);
}

function action(mode, type, selection) {
    if (mode == 1)
        status++;
    else {
        cm.dispose();
        return;
    }
    if (status == 0) {
            var tex2 = "";
            var text = "";
            for (i = 0; i < 10; i++) {
                text += "";
            }
			//显示物品ID图片用的代码是  #v这里写入ID#
            text += "#k\t\t\t\t欢迎来到#r" + fbmc + "#k\r\n进入要求如下：\r\n①人数限制:#r " + minPartySize + " #b- #r" + maxPartySize + "#k队员\t②等级限制：#r " + minLevel + " #b- #r" + maxLevel + "级 #k\r\n"
			text += "#k每天只能挑战:#b"+ cishuxianzhi +"#k次 你今天已进入:#b"+ cm.getPlayer().getBossLog("qichongcs") +"#k次#k\r\n"
            text += "#L1##r开始挑战#l\r\n\r\n"
            cm.sendSimple(text);
	} else if (selection == 1) {
		if (cm.isQuestFinished(6002)) {//判断任务
                    cm.sendOk("你已经完成了骑兽任务。");
                    cm.dispose();
        } else if (!cm.isQuestActive(6002)) {//判断任务
                    cm.sendOk("你没有接受有骑兽任务。");
                    cm.dispose();
		} else if (cm.getParty() == null) {
            cm.sendOk("你没有队伍无法进入！");
            cm.dispose();
			return;
		} else if (!cm.getPlayerCount(923010000) <= 0) {
	             cm.sendOk("里面有人,请稍后.");
				 cm.dispose();
        } else if (!cm.isLeader()) { 
            cm.sendOk("请让你的队长和我说话~");
            cm.dispose();
			return;
        } else {
            var party = cm.getParty().getMembers();
            var inMap = cm.partyMembersInMap();
            var levelValid = 0;
            for (var i = 0; i < party.size(); i++) {
                if (party.get(i).getLevel() >= minLevel && party.get(i).getLevel() <= maxLevel)
                    levelValid++;
            }
            if (inMap < minPartySize || inMap > maxPartySize) {
                cm.sendOk("你的队伍人数不足"+minPartySize+"人.请把你的队伍人员召集到水下世界在进入.");
                cm.dispose();
				return;
            } else if (levelValid != inMap) {
                cm.sendOk("请确保你的队伍里所有人员都在本地图，且最小等级在 "+minLevel+" 和 "+maxLevel+"之间.");
                cm.dispose();
				return;
			}else if(cm.getPartyBosslog("qichongcs",(cishuxianzhi-1)) == false) {//判断组队是否2次
	            cm.sendOk("队伍中队友挑战次数已经用完2次！");
                cm.dispose();
				return;
			}else if( cm.getPlayer().getBossLog("qichongcs") >= cishuxianzhi) {
	            cm.sendOk("您好,限定每天只能挑战"+ cishuxianzhi +"次！");
                cm.dispose();
				return;
            } else {
                var em = cm.getEventManager("Qichong");
                if (em == null) {
                    cm.sendOk("这台电脑是当前不可用.");
                //} else if (em.getProperty("KPQOpen").equals("true")) {
                } else {
        if (cm.getPlayerCount(923010000) <= 0) {
                em.startInstance(cm.getParty(), cm.getPlayer().getMap());
				cm.setPartyBosslog("qichongcs");//给团队次数
				cm.getMap(923010000).resetFully();//地图刷新
                cm.removeAll(4031507);
                cm.removeAll(4031508);
		} else {
                            cm.sendOk("请稍等...任务正在进行中.");
                        }

                }
                cm.dispose();
            }
        }
}}