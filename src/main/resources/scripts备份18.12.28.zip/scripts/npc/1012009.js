/*
	NPC Name: 		Mr. Lee
	Map(s): 		Victoria Road : Henesys (100000000)
	Description: 		Storage
*/
function start() {
	cm.sendStorage();
	cm.dispose();
}