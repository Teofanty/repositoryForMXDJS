/* 	Aramia
 * 	Henesys fireworks NPC
 */

var status = 0;

function start() {
	status = -1;
	action(1, 0, 0);
}

function action(mode, type, selection) { 
var 序号=0;
		var 最大值=cm.getPMAX(5);
		var 自己捐献数量 = cm.getPNew(5);
	if (mode == -1) {
        cm.dispose();
    } else {
		if (mode == 1) {
			status++;
		} else {
			cm.dispose();
			return;
		}
    /*if (cm.getClient().getChannel() >= 2) {
        cm.sendNext("只能在1频道进行捐献.");
        cm.dispose();
        return;
    }*/
    if (status == 0) {
        cm.sendNext("黑暗……黑暗……黑暗尼玛比啊！又要来一次……\r\n这要捐到什么时候！又要面对两只傻逼蝙蝠怪！\r\n你来夹在它们中间试试！（20%开放蚂蚁广场）");
    } else if (status == 1) {
		
		var textx = "您当前在#e#b金银岛#k#n已捐献的闪光的碎沙数量为："+自己捐献数量+"个\r\n";
		if(cm.getPlayer().isGM()){
		cm.sendSimple("林中之城是整个黑暗力量的#r中心地带#k！净化#r<林中之城>#k需要-#b闪光的碎沙#k，解锁城市后，该城市大部分地区将解除封印，恢复活力。 \n\r #b#L0# 我把闪光的碎沙带来了。#l#k \n\r #b#L1# 请告诉我现在的收集进度。#l#k \n\r #b#L2# 清理记忆拼图(只有GM才会显示)。 #l#k \n\r\n\r #b< 在库存的记忆拼图数 :"+自己捐献数量+" 最大值 "+最大值+"个 >#k");
		}else{
			cm.sendSimple("林中之城是整个黑暗力量的#r中心地带#k！净化#r<林中之城>##k需要-#b闪光的碎沙#k，解锁城市后，该城市大部分地区将解除封印，恢复活力。 \n\r #b#L0# 我把闪光的碎沙带来了。#l#k \n\r #b#L1# 请告诉我现在的收集进度。#l#k");
		}
    } else if (status == 2) {
        if (selection == 1) {
            cm.sendNext("闪光的碎沙收集现状 \n\r #B" + cm.getPercentage(自己捐献数量,最大值) + "# "+cm.getPercentage(自己捐献数量,最大值)+"%\n\r 如果我们把它们集中起来，该地图的封印就解除了……");
            //cm.safeDispose();
        cm.dispose();
        } else if (selection == 2) {
			 
	  cm.gainPNew(-cm.getPNew(5), 5);
        cm.sendNext("清理成功.");
        cm.dispose();
        } else if (selection == 0) {
            cm.sendGetNumber("你把拼图的的力量带来了吗？那么，请给我#e#b闪光的碎沙#n#k。到达一定数量，该地区扎昆的力量将完全净化。#k", 1, 1, 10000);
        }
    } else if (status == 3) {
        var num = selection;
        if (num == 0) {
            cm.sendOk("小子，你包里真的有拼图的力量吗？\r\n 别拿这种事开玩笑！");
		}else if(最大值 < 自己捐献数量 + num){
            cm.sendOk("多了多了，快要成功了！！");
        } else if (cm.haveItem(4001398, num)) {
            cm.gainItem(4001398, -num);
			cm.gainItem(2022465, num);
			cm.getPlayer().modifyCSPoints(2,+Math.floor(1 * num));
            //cm.giveKegs(num, 1);
			cm.gainPNew(num, 5);
			cm.worldMessage(0x00,"玩家 "+cm.getPlayer().getName()+" 成功将拼图的力量 【闪光的碎沙】捐赠<林中之城>，并获得" + Math.floor(1 * num) + "抵用卷 ");
		if(cm.getPercentage(cm.getPNew(5),最大值)==100){
			cm.getPlayer().MapEffectlaba("勇士们！ "+cm.getPlayer().getName()+" 已将最后一块【闪光的碎沙】交给指路牌,<林中之城>即将解除部分封印！");	
			cm.worldMessage(0x00,"玩家 "+cm.getPlayer().getName()+" 已将最后一块【闪光的碎沙】交给指路牌,<林中之城>即将解除部分封印！ ");
			}
			
            cm.sendOk("当你拿到记忆拼图时别忘了把记忆拼图给我\r\n你已获得 #b" + Math.floor(1 * num) + "#k #r抵用卷#k");
        }else{
            cm.sendOk("小子，你包里真的有拼图的力量吗？\r\n 别拿这种事开玩笑！");
		}
        cm.dispose();
		}
	}
}
