/*
	Gerrad - Ariant(260000200)
*/

function start() {
    cm.sendStorage();
    cm.dispose();
}