/* Author: aaroncsn(MapleSea Like)
	NPC Name: 		Assistant Cheng
	Map(s): 		Ludibrium: Toy Factory Zone 1(220020000)
	Description: 		Unknown
*/

function start(){
	cm.sendNext("多亏了你，玩具工厂又恢复了正常运转。我很高兴你来帮助我们，所以不必担心。那么，我需要回去工作继续工作了!");
	cm.warp(922000000);
	cm.dispose();
	}