
function action(mode, type, selection) {
    if (cm.getQuestStatus(6230) != 1) {
		cm.sendOk("你没有接受相关的职业任务！" );
		cm.dispose();
	} else if (cm.getInventory(1).isFull(0)){//判断第一个也就是装备栏的装备栏是否有一个空格
		cm.sendOk("#b请保证装备栏位至少有1个空格,否则无法继续！");
	    cm.dispose()
	} else if (!cm.haveItem(4031476)) {
		cm.sendOk("#b你没有带来#v4031476#！");
	    cm.dispose()
	} else {
		    cm.gainItem(4031476, -1);
			cm.gainItem(4031456, 1);
		    cm.sendOk("枫叶吸收到闪闪发光的玻璃球." );
		    cm.dispose();
		}
    }
