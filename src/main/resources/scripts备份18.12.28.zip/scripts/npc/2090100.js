/* Grandpa Luo
	Mu Lung VIP Hair/Hair Color Change.
*/
var status = -1;
var beauty = 0;
var hair_Colo_new;

function start() {
    action(1, 0, 0);
}

function action(mode, type, selection) {
    if (mode == 0) {
	cm.dispose();
	return;
    } else {
	status++;
    }

    if (status == 0) {
	cm.sendSimple("欢迎来到武陵理发店。 如果你有#b#t5150025##k, 或者 #b#t5151020##k, 让我照顾你的发型。 请选择你想要的那个.\r\n#L0#理发： #i5150025##t5150025##l\r\n#L1#染发: #i5151020##t5151020##l");
    } else if (status == 1) {
	if (selection == 0) {
	    var hair = cm.getPlayerStat("HAIR");
	    hair_Colo_new = [];
	    beauty = 1;

	    if (cm.getPlayerStat("GENDER") == 0) {
		hair_Colo_new = [30250, 30350, 30270, 30150, 30300, 30600, 30160];
	    } else {
		hair_Colo_new = [31040, 31250, 31310, 31220, 31300, 31680, 31160, 31030, 31230];
	    }
	    for (var i = 0; i < hair_Colo_new.length; i++) {
		hair_Colo_new[i] = hair_Colo_new[i] + (hair % 10);
	    }
	    cm.askAvatar("我可以完全改变你的发型，使它看起来很好。 你为什么不改变一下？ #v5150025##k，我将为您处理剩下的事情。 选择你喜欢的风格!", hair_Colo_new);
	} else if (selection == 1) {
	    var currenthaircolo = Math.floor((cm.getPlayerStat("HAIR") / 10)) * 10;
	    hair_Colo_new = [];
	    beauty = 2;

	    for (var i = 0; i < 8; i++) {
		hair_Colo_new[i] = currenthaircolo + i;
	    }
	    cm.askAvatar("我可以完全改变你的头发颜色，使它看起来很好。 你为什么不改变一下？同 #b#t5151020##k, 我会照顾其余的。 选择你喜欢的颜色!", hair_Colo_new);
	}
    } else if (status == 2){
	if (beauty == 1) {
	    if (cm.setAvatar(5150025, hair_Colo_new[selection]) == 1) {
		cm.sendOk("享受您新的和改进的发型!");
		cm.dispose();
	    } else {
		cm.sendOk("嗯......看起来你没有我们指定的优惠券......我担心没有它就不能给你理发。 对不起...");
		cm.dispose();
	    }
	} else {
	    if (cm.setAvatar(5151020, hair_Colo_new[selection]) == 1) {
		cm.sendOk("享受新的和改进的头发颜色!");
		cm.dispose();
	    } else {
		cm.sendOk("嗯......看起来你没有我们指定的优惠券......我担心如果没有它我就不能脱掉你的头发。 对不起...");
		cm.dispose();
	    }
	}
	cm.dispose();
    }
}