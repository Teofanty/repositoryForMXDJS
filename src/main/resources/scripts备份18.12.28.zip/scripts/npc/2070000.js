/* Storage
*/

function start() {
    cm.sendStorage();
	 cm.dispose();
}

function action(mode, type, selection) {
    cm.dispose();
}