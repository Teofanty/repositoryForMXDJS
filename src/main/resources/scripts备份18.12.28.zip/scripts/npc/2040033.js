/*
	Neru - Ludibrium : Ludibrium Pet Walkway (220000006)
*/

var status = 0;

function start() {
    status = -1;
    action(1, 0, 0);
}

function action(mode, type, selection) {
    if (status >= 0 && mode == 0) {
	cm.dispose();
	return;
    }
    if (mode == 1)
	status++;
    else
	status--;
    if (status == 0) {
	if (cm.haveItem(4031128)) {
	    cm.sendNext("呃，这是我兄弟的来信！ 可能是因为我认为我不工作而骂我......呃？ 啊......你听从了我兄弟的建议，训练了你的宠物，然后起身来了，对吧？尼斯！ 既然你努力到达这里，我会提高你和宠物的亲密程度.");
	} else {
	    cm.sendOk("我哥哥告诉我照顾宠物障碍训练课程，但是......因为我离他很远，所以我忍不住想要四处走动......呵呵，因为我没有看到他 视线，不妨只是冷静几分钟.");
	    cm.dispose();
	}
    } else if (status == 1) {
	if (cm.getPlayer().getPet(0) == null) {
	    cm.sendNextPrev("嗯......你和你的宠物真的到了吗？ 这些障碍适用于宠物。 没有它，你在这里干什么？ 你出去!");
	    cm.dispose();
	} else {
	    cm.gainItem(4031128, -1);
	    cm.gainClosenessAll(4);
	    cm.sendNextPrev("你怎么看？ 难道你不觉得你和宠物的关系越来越近了吗？ 如果你有时间，在这个障碍训练场上再次训练你的宠物......当然，在我哥哥允许的情况下.");
	    cm.dispose();
	}
    }
}