function action(mode, type, selection) {
    cm.sendNext("Let's go!");
    cm.dispose();
}