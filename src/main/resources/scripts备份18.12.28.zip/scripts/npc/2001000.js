

function action(mode, type, selection) {
   cm.sendOk("你看到那群雪人站在那边吗？ 这真是太棒了！ 在那里，你可以使用各种装饰品装饰树。 你怎么看？ 听起来很有趣，对?.");
   cm.dispose();
}