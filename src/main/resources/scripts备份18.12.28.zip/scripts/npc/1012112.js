﻿/* ==================
 脚本类型: NPC	    
 脚本版权：游戏盒团队
 联系扣扣：297870163
 =====================
 */
var status = 0;
var fbmc = "射手村公园-(月妙副本)";//副本名称
var minLevel = 8;//最低等级
var maxLevel = 200;//最高等级
var minPartySize = 2;//最低人数
var maxPartySize = 6;//最高人数
var cishuxianzhi = 10;//限制次数
var maxjinbi = 50000;//判断征集令金币
var eventname = "HenesysPQ";//副本配置文件


function start() {
    status = -1;
    action(1, 0, 0);
}

function action(mode, type, selection) {
    if (mode == -1) {
        cm.dispose();
    } else {
        if (mode == 0 && status == 0) {
            cm.dispose();
            return;
        }
        if (mode == 1) status++;
        else status--;
        if (status == 0) {
		if (cm.getPlayer().getMapId() == 910010400) {//在胜利那里掉线这里返回
	cm.removeAll(4001101);
    cm.removeAll(4001095);
    cm.removeAll(4001096);
    cm.removeAll(4001097);
    cm.removeAll(4001098);
    cm.removeAll(4001099);
    cm.removeAll(4001100);
        cm.warp(100000200);
		cm.dispose();
		 return;
		}
			var tex2 = "";
            var text = "";
            for (i = 0; i < 10; i++) {
                text += "";
            }
			//显示物品ID图片用的代码是  #v这里写入ID#
            text += "#k\t\t\t\t欢迎来到#r" + fbmc + "#k\r\n副本进入要求如下：\r\n①人数限制:#r " + minPartySize + " #b- #r" + maxPartySize + "#k队员\t②等级限制：#r " + minLevel + " #b- #r" + maxLevel + "级 #k\r\n"
			text += "#k已完成挑战:#r"+cm.getPlayer().getOneTimeLog("yuemiao")+"#k次   每天只能挑战:#b"+ cishuxianzhi +"#k次 你今天已进入:#b"+ cm.getPlayer().getBossLog("yuemiaocs") +"#k次#k\r\n"
            text += "#L0##r开始组队副本#l      #L1##r副本征集令#k" + maxjinbi + "金币/次#l\r\n\r\n"
			text += "#L2##r挑战满50次领取#v1002798##z1002798##l\r\n\r\n"
            cm.sendSimple(text);
        } else if (status == 1) {
            if (selection == 0) {
                if (cm.getParty() == null) { // 没有组队
                    cm.sendOk("请组队后和我谈话。");
                    cm.dispose();
                } else if (!cm.isLeader()) { // 不是队长
                    cm.sendOk("请叫队长和我谈话。");
                    cm.dispose();
				}else if(cm.getPartyBosslog("yuemiaocs",(cishuxianzhi-1)) == false) {//判断组队是否2次
	            cm.sendOk("队伍中队友挑战次数已经用完10次！");
                cm.dispose();
				return;
			   }else if( cm.getPlayer().getBossLog("yuemiaocs") >= cishuxianzhi) {
	            cm.sendOk("您好,限定每天只能挑战"+ cishuxianzhi +"次！");
                cm.dispose();
				return;
                } else {
					cm.givePartyItems(4001095,-1,true);
					cm.givePartyItems(4001096,-1,true);
					cm.givePartyItems(4001097,-1,true);
					cm.givePartyItems(4001098,-1,true);
					cm.givePartyItems(4001099,-1,true);
					cm.givePartyItems(4001100,-1,true);
                    var party = cm.getParty().getMembers();
                    var mapId = cm.getPlayer().getMapId();
                    var next = true;
                    var levelValid = 0;
                    var inMap = 0;
                    var it = party.iterator();
                    while (it.hasNext()) {
                        var cPlayer = it.next();
                        if ((cPlayer.getLevel() >= minLevel) && (cPlayer.getLevel() <= maxLevel)) {
                            levelValid += 1;
                        } else {
                            next = false;
                        }
                        if (cPlayer.getMapid() == mapId) {
                            inMap += 1;
                        }
                    }
                    if (party.size() < minPartySize || party.size() > maxPartySize || inMap < minPartySize) {
                        next = false;
                    }
                    if (next) {
                        var em = cm.getEventManager("HenesysPQ");
                        if (em == null) {
                            cm.sendOk("此任务正在建设当中。");
                        } else {
                            var prop = em.getProperty("state");
                            if (prop.equals("0") || prop == null) {
                                em.startInstance(cm.getParty(), cm.getMap());
                                cm.removeAll(4001022);
                                cm.removeAll(4001023);
								cm.setPartyBosslog("yuemiaocs");//给团队次数
                                cm.dispose();
                                return;
                            } else {
                                cm.sendOk("任务正在进行中...请稍等!");
                            }
                        }
                        cm.dispose();
                    } else {
                        cm.sendOk("请确认你的组队员：\r\n\r\n#b1、组队员必须要" + minPartySize + "人以上，" + maxPartySize + "人以下。\r\n2、组队员等级必须要在" + minLevel + "级以上。\r\n\r\n（#r如果仍然错误, 重新下线,再登陆 或者请重新组队。#k#b）");
                        cm.dispose();
                    }
                } 
            } else if (selection == 1) {
		if (cm.getMeso() >= maxjinbi){//判断多少金币
        cm.gainMeso(- maxjinbi );//扣除多少金币
	    cm.laba(cm.getPlayer().getName() + " [征集令]" + " : " + "["+ fbmc +"]需要勇士一起完成",11);
        cm.dispose();
        }else{
        cm.sendOk("你的冒险币不足" + maxjinbi + "。无法发送征集令");
        cm.dispose();
				}
			 } else if (selection == 2) {
				 if (cm.getInventory(1).isFull(0)){//判断第一个也就是装备栏的装备栏是否有一个空格
		cm.sendOk("#b请保证装备栏位至少有1个空格,否则无法兑换.");
		cm.dispose();
		} else if(cm.getPlayer().getOneTimeLog("yuemiao1") >= 1){//判断永久记录
		cm.sendOk("你已经领取过了,无法在重复领取!");
        cm.dispose();
		} else if(cm.getPlayer().getOneTimeLog("yuemiao") < 50){//判断永久记录
		cm.sendOk("你还没有成功挑战够50次,当前已经挑战成功了:"+cm.getPlayer().getOneTimeLog("yuemiao")+"次!");
        status = -1;
		} else {
        cm.getPlayer().setOneTimeLog("yuemiao1");//给永久记录
		cm.gainItem(1002798, 1, true);//物品代码,数量,随机属性
		cm.sendOk("恭喜你,成功的领取了#v1002798##z1002798#!");
        cm.worldMessage(6,"恭喜玩家：["+cm.getName()+"]在月妙副本中成功的兑换了年糕帽!");
	    status = -1;
            }
        }
}
}}