var status = -1;

function action(mode, type, selection) {
	cm.sendSimple("我现在很忙,请找我的外科助理!");
	cm.dispose();
}