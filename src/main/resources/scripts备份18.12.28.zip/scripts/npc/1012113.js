
function action(mode, type, selection) {
    cm.removeAll(4001101);
    cm.removeAll(4001095);
    cm.removeAll(4001096);
    cm.removeAll(4001097);
    cm.removeAll(4001098);
    cm.removeAll(4001099);
    cm.removeAll(4001100);
    if (cm.getPlayer().getMapId() == 910010200 ||cm.getPlayer().getMapId() == 910010300 ) {
        cm.warp(100000200);
		cm.dispose();
	} else if (cm.getPlayer().getMapId() == 910010100) {//通关
        cm.warp(910010200);
		cm.getPlayer().setOneTimeLog("yuemiao");//给永久记录
		cm.dispose();
    } else {
        cm.warp(100000200);
		cm.dispose();
    }
}