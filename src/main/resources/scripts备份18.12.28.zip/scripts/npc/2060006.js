var status = -1;

function action(mode, type, selection) {
	cm.sendOk("我在这里过的很好，你呢.");
    cm.dispose();
}